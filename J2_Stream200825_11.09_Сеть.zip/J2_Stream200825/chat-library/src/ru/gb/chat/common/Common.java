package ru.gb.chat.common;

public class Common {
}
