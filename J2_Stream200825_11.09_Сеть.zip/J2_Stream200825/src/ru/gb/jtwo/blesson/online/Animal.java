package ru.gb.jtwo.blesson.online;

public interface Animal {
    void breathe();
    void look();
}
