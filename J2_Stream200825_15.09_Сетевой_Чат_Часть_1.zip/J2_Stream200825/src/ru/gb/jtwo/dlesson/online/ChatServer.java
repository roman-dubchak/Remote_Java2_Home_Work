package ru.gb.jtwo.dlesson.online;

public class ChatServer {
    public void start(int port) {
        System.out.println("Server started at port: " + port);
    }

    public void stop() {
        System.out.println("Server stopped");
    }
}
