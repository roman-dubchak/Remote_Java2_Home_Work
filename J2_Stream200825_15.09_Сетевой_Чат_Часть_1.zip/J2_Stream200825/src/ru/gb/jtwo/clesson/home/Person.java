package ru.gb.jtwo.clesson.home;

public class Person {

    public String name;
    public String phone;
    public String email;

    public Person(String name, String phone, String email) {
        this.name = name;
        this.phone = phone;
        this.email = email;
    }
}
