package ru.gb.chat.server.core;

public interface ChatServerListener {
    void onChatServerMessage(String msg);
}
